package com.goufn.permission.model;

import lombok.Data;


@Data
public class SysRoleMenu extends BaseModel {

    private Long roleId;

    private Long menuId;
}

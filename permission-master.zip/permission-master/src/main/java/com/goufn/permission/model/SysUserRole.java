package com.goufn.permission.model;

import lombok.Data;


@Data
public class SysUserRole extends BaseModel {

    private Long userId;

    private Long roleId;

}

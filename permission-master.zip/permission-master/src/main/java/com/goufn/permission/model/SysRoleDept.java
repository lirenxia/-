package com.goufn.permission.model;

import lombok.Data;

@Data
public class SysRoleDept extends BaseModel {

    private Long roleId;

    private Long deptId;
}
